﻿namespace VibeCollection.API.Models
{
    public class WomenCollectionItem
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public decimal Price { get; set; }
        public string Image1 { get; set; } = string.Empty;
        public string? Image2 { get; set; }
        public string Description { get; set; } = string.Empty;
    }
}

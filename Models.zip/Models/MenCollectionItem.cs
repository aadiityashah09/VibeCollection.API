﻿namespace VibeCollection.API.Models
{
    public class MenCollectionItem
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public string Price { get; set; } = string.Empty;  // As per SQL it's varchar
        public string Image { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
    }
}

﻿using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;
using System.Data;
using VibeCollection.API.Data;
using VibeCollection.API.Models;

namespace VibeCollection.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MenCollectionController : ControllerBase
    {
        private readonly DatabaseHelper _db;

        public MenCollectionController(DatabaseHelper db)
        {
            _db = db;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<MenCollectionItem>>> GetMenItems()
        {
            var query = "SELECT * FROM men_collection";
            var table = await _db.ExecuteQueryAsync(query);

            var result = new List<MenCollectionItem>();
            foreach (DataRow row in table.Rows)
            {
                result.Add(new MenCollectionItem
                {
                    Id = Convert.ToInt32(row["id"]),
                    Name = row["name"].ToString()!,
                    Price = row["price"].ToString()!,
                    Image = row["image"].ToString()!,
                    Description = row["description"].ToString()!
                });
            }

            return Ok(result);
        }

        [HttpPost]
        public async Task<ActionResult> CreateMenItem(MenCollectionItem item)
        {
            string query = @"INSERT INTO men_collection (name, price, image, description)
                             VALUES (@name, @price, @image, @description)";
            var parameters = new List<MySqlParameter>
            {
                new("@name", item.Name),
                new("@price", item.Price),
                new("@image", item.Image),
                new("@description", item.Description)
            };

            int rows = await _db.ExecuteNonQueryAsync(query, parameters);
            return rows > 0 ? Ok(new { message = "Men's item added" }) : BadRequest("Insert failed");
        }
    }
}

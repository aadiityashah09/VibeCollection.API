﻿using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;
using System.Data;
using VibeCollection.API.Data;
using VibeCollection.API.Models;

namespace VibeCollection.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class KidsCollectionController : ControllerBase
    {
        private readonly DatabaseHelper _db;

        public KidsCollectionController(DatabaseHelper db)
        {
            _db = db;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<KidsCollectionItem>>> GetAll()
        {
            string query = "SELECT * FROM kids_collection";
            var table = await _db.ExecuteQueryAsync(query);

            var result = new List<KidsCollectionItem>();
            foreach (DataRow row in table.Rows)
            {
                result.Add(new KidsCollectionItem
                {
                    Id = Convert.ToInt32(row["id"]),
                    Name = row["name"].ToString()!,
                    Price = Convert.ToDecimal(row["price"]),
                    Description = row["description"].ToString()!,
                    CreatedAt = Convert.ToDateTime(row["created_at"])
                });
            }

            return Ok(result);
        }

        [HttpPost]
        public async Task<ActionResult> Add(KidsCollectionItem item)
        {
            string query = @"INSERT INTO kids_collection (name, price, description)
                             VALUES (@name, @price, @description)";
            var parameters = new List<MySqlParameter>
            {
                new("@name", item.Name),
                new("@price", item.Price),
                new("@description", item.Description)
            };

            int rows = await _db.ExecuteNonQueryAsync(query, parameters);
            return rows > 0 ? Ok(new { message = "Kids item added" }) : BadRequest("Insert failed");
        }
    }
}

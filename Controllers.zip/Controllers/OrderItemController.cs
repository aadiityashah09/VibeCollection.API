﻿using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;
using System.Data;
using VibeCollection.API.Data;
using VibeCollection.API.Models;

namespace VibeCollection.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderItemsController : ControllerBase
    {
        private readonly DatabaseHelper _db;

        public OrderItemsController(DatabaseHelper db)
        {
            _db = db;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<OrderItem>>> GetAll()
        {
            string query = "SELECT * FROM order_items";
            var table = await _db.ExecuteQueryAsync(query);

            var items = new List<OrderItem>();
            foreach (DataRow row in table.Rows)
            {
                items.Add(new OrderItem
                {
                    Id = Convert.ToInt32(row["id"]),
                    OrderId = Convert.ToInt32(row["order_id"]),
                    ProductId = Convert.ToInt32(row["product_id"]),
                    Quantity = Convert.ToInt32(row["quantity"]),
                    TotalPrice = Convert.ToDecimal(row["total_price"])
                });
            }

            return Ok(items);
        }

        [HttpPost]
        public async Task<ActionResult> Create(OrderItem item)
        {
            var query = @"
                INSERT INTO order_items (order_id, product_id, quantity, total_price)
                VALUES (@order_id, @product_id, @quantity, @total_price)";

            var parameters = new List<MySqlParameter>
            {
                new("@order_id", item.OrderId),
                new("@product_id", item.ProductId),
                new("@quantity", item.Quantity),
                new("@total_price", item.TotalPrice)
            };

            var rows = await _db.ExecuteNonQueryAsync(query, parameters);
            return rows > 0 ? Ok(new { message = "Order item added" }) : BadRequest("Insert failed");
        }
    }
}

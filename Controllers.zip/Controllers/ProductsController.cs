﻿using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;
using System.Data;
using VibeCollection.API.Data;
using VibeCollection.API.Models;

namespace VibeCollection.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        private readonly DatabaseHelper _db;

        public ProductsController(DatabaseHelper db)
        {
            _db = db;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Product>>> GetAll()
        {
            var query = "SELECT * FROM products";
            var table = await _db.ExecuteQueryAsync(query);

            var products = new List<Product>();
            foreach (DataRow row in table.Rows)
            {
                products.Add(new Product
                {
                    Id = Convert.ToInt32(row["id"]),
                    Name = row["name"]?.ToString(),
                    Price = row["price"] != DBNull.Value ? Convert.ToDecimal(row["price"]) : null
                });
            }

            return Ok(products);
        }

        [HttpPost]
        public async Task<ActionResult> Add(Product product)
        {
            var query = "INSERT INTO products (name, price) VALUES (@name, @price)";
            var parameters = new List<MySqlParameter>
            {
                new("@name", (object?)product.Name ?? DBNull.Value),
                new("@price", (object?)product.Price ?? DBNull.Value)
            };

            var rows = await _db.ExecuteNonQueryAsync(query, parameters);
            return rows > 0 ? Ok(new { message = "Product added" }) : BadRequest("Insert failed");
        }
    }
}

﻿using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;
using System.Data;
using VibeCollection.API.Data;
using VibeCollection.API.Models;

namespace VibeCollection.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class WomenCollectionController : ControllerBase
    {
        private readonly DatabaseHelper _db;

        public WomenCollectionController(DatabaseHelper db)
        {
            _db = db;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<WomenCollectionItem>>> GetWomenItems()
        {
            var query = "SELECT * FROM women_collection";
            var table = await _db.ExecuteQueryAsync(query);

            var result = new List<WomenCollectionItem>();
            foreach (DataRow row in table.Rows)
            {
                result.Add(new WomenCollectionItem
                {
                    Id = Convert.ToInt32(row["id"]),
                    Name = row["name"].ToString()!,
                    Price = Convert.ToDecimal(row["price"]),
                    Image1 = row["image1"].ToString()!,
                    Image2 = row["image2"]?.ToString(),
                    Description = row["description"].ToString()!
                });
            }

            return Ok(result);
        }

        [HttpPost]
        public async Task<ActionResult> CreateWomenItem(WomenCollectionItem item)
        {
            string query = @"INSERT INTO women_collection (name, price, image1, image2, description)
                             VALUES (@name, @price, @image1, @image2, @description)";
            var parameters = new List<MySqlParameter>
            {
                new("@name", item.Name),
                new("@price", item.Price),
                new("@image1", item.Image1),
                new("@image2", (object?)item.Image2 ?? DBNull.Value),
                new("@description", item.Description)
            };

            int rows = await _db.ExecuteNonQueryAsync(query, parameters);
            return rows > 0 ? Ok(new { message = "Women's item added" }) : BadRequest("Insert failed");
        }
    }
}

﻿using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;
using System.Data;
using VibeCollection.API.Data;
using VibeCollection.API.Models;

namespace VibeCollection.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomersController : ControllerBase
    {
        private readonly DatabaseHelper _db;

        public CustomersController(DatabaseHelper db)
        {
            _db = db;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Customer>>> GetCustomers()
        {
            var query = "SELECT * FROM customers";
            var table = await _db.ExecuteQueryAsync(query);

            var result = new List<Customer>();
            foreach (DataRow row in table.Rows)
            {
                result.Add(new Customer
                {
                    Id = Convert.ToInt32(row["id"]),
                    Name = row["name"].ToString()!,
                    Email = row["email"].ToString()!,
                    Username = row["username"].ToString()!,
                    Password = row["password"].ToString()!
                });
            }

            return Ok(result);
        }

        [HttpPost]
        public async Task<ActionResult> CreateCustomer(Customer customer)
        {
            string query = @"INSERT INTO customers (name, email, username, password) 
                             VALUES (@name, @email, @username, @password)";
            var parameters = new List<MySqlParameter>
            {
                new("@name", customer.Name),
                new("@email", customer.Email),
                new("@username", customer.Username),
                new("@password", customer.Password)
            };

            int rows = await _db.ExecuteNonQueryAsync(query, parameters);
            return rows > 0 ? Ok(new { message = "Customer created" }) : BadRequest("Insert failed");
        }
    }
}

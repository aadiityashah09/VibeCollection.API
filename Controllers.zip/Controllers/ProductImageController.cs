﻿using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;
using System.Data;
using VibeCollection.API.Data;
using VibeCollection.API.Models;

namespace VibeCollection.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductImagesController : ControllerBase
    {
        private readonly DatabaseHelper _db;

        public ProductImagesController(DatabaseHelper db)
        {
            _db = db;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<ProductImage>>> GetAll()
        {
            string query = "SELECT * FROM product_images";
            var table = await _db.ExecuteQueryAsync(query);

            var result = new List<ProductImage>();
            foreach (DataRow row in table.Rows)
            {
                result.Add(new ProductImage
                {
                    Id = Convert.ToInt32(row["id"]),
                    ProductId = Convert.ToInt32(row["product_id"]),
                    ImagePath = row["image_path"].ToString()!
                });
            }

            return Ok(result);
        }

        [HttpPost]
        public async Task<ActionResult> Add(ProductImage image)
        {
            var query = @"INSERT INTO product_images (product_id, image_path)
                          VALUES (@product_id, @image_path)";
            var parameters = new List<MySqlParameter>
            {
                new("@product_id", image.ProductId),
                new("@image_path", image.ImagePath)
            };

            int rows = await _db.ExecuteNonQueryAsync(query, parameters);
            return rows > 0 ? Ok(new { message = "Image added" }) : BadRequest("Insert failed");
        }
    }
}

﻿using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;
using System.Data;
using VibeCollection.API.Data;
using VibeCollection.API.Models;

namespace VibeCollection.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdminsController : ControllerBase
    {
        private readonly DatabaseHelper _db;

        public AdminsController(DatabaseHelper db)
        {
            _db = db;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Admin>>> GetAllAdmins()
        {
            try
            {
                string query = "SELECT * FROM admins";
                var table = await _db.ExecuteQueryAsync(query);
                var result = new List<Admin>();

                foreach (DataRow row in table.Rows)
                {
                    result.Add(new Admin
                    {
                        Id = Convert.ToInt32(row["id"]),
                        Username = row["username"].ToString()!,
                        Password = row["password"].ToString()!,
                        CreatedAt = Convert.ToDateTime(row["created_at"])
                    });
                }

                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while retrieving admins", error = ex.Message });
            }
        }

        [HttpPost]
        public async Task<ActionResult> CreateAdmin([FromBody] Admin admin)
        {
            if (admin == null || string.IsNullOrEmpty(admin.Username) || string.IsNullOrEmpty(admin.Password))
            {
                return BadRequest("Username and password are required");
            }

            try
            {
                string query = "INSERT INTO admins (username, password) VALUES (@username, @password)";
                var parameters = new List<MySqlParameter>
                {
                    new MySqlParameter("@username", admin.Username),
                    new MySqlParameter("@password", admin.Password)
                };

                int rows = await _db.ExecuteNonQueryAsync(query, parameters);
                return rows > 0
                    ? Ok(new { message = "Admin created successfully" })
                    : BadRequest("Insert failed");
            }
            catch (MySqlException ex) when (ex.Number == 1062) // Duplicate entry
            {
                return Conflict(new { message = "Username already exists" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while creating admin", error = ex.Message });
            }
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult> DeleteAdmin(int id)
        {
            if (id <= 0)
            {
                return BadRequest("Invalid admin ID");
            }

            try
            {
                string query = "DELETE FROM admins WHERE id = @id";
                var parameters = new List<MySqlParameter>
                {
                    new MySqlParameter("@id", id)
                };

                int rows = await _db.ExecuteNonQueryAsync(query, parameters);
                return rows > 0
                    ? Ok(new { message = "Admin deleted successfully" })
                    : NotFound(new { message = "Admin not found" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while deleting admin", error = ex.Message });
            }
        }
    }
}
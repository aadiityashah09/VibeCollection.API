﻿using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;
using System.Data;
using VibeCollection.API.Data;
using VibeCollection.API.Models;

namespace VibeCollection.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrdersController : ControllerBase
    {
        private readonly DatabaseHelper _db;

        public OrdersController(DatabaseHelper db)
        {
            _db = db;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Order>>> GetOrders()
        {
            var query = "SELECT * FROM orders";
            var table = await _db.ExecuteQueryAsync(query);

            var orders = new List<Order>();
            foreach (DataRow row in table.Rows)
            {
                orders.Add(new Order
                {
                    Id = Convert.ToInt32(row["id"]),
                    CustomerName = row["customer_name"].ToString()!,
                    Address = row["address"].ToString()!,
                    Email = row["email"].ToString()!,
                    Phone = row["phone"].ToString()!,
                    TotalPrice = Convert.ToDecimal(row["total_price"]),
                    ShippingFee = Convert.ToDecimal(row["shipping_fee"]),
                    TotalAmount = Convert.ToDecimal(row["total_amount"]),
                    PaymentMethod = row["payment_method"].ToString()!,
                    OrderDate = Convert.ToDateTime(row["order_date"]),
                    CreatedAt = Convert.ToDateTime(row["created_at"]),
                    CustomerId = row["customer_id"] != DBNull.Value ? Convert.ToInt32(row["customer_id"]) : null,
                    UserId = row["user_id"] != DBNull.Value ? Convert.ToInt32(row["user_id"]) : null
                });
            }

            return Ok(orders);
        }

        [HttpPost]
        public async Task<ActionResult> CreateOrder(Order order)
        {
            var query = @"
                INSERT INTO orders 
                (customer_name, address, email, phone, total_price, shipping_fee, total_amount, payment_method, customer_id, user_id)
                VALUES 
                (@customer_name, @address, @email, @phone, @total_price, @shipping_fee, @total_amount, @payment_method, @customer_id, @user_id)";

            var parameters = new List<MySqlParameter>
            {
                new("@customer_name", order.CustomerName),
                new("@address", order.Address),
                new("@email", order.Email),
                new("@phone", order.Phone),
                new("@total_price", order.TotalPrice),
                new("@shipping_fee", order.ShippingFee),
                new("@total_amount", order.TotalAmount),
                new("@payment_method", order.PaymentMethod),
                new("@customer_id", (object?)order.CustomerId ?? DBNull.Value),
                new("@user_id", (object?)order.UserId ?? DBNull.Value)
            };

            int rows = await _db.ExecuteNonQueryAsync(query, parameters);
            return rows > 0 ? Ok(new { message = "Order created" }) : BadRequest("Insert failed");
        }
    }
}

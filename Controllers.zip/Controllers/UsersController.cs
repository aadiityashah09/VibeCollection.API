﻿using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;
using System.Data;
using VibeCollection.API.Data;
using VibeCollection.API.Models;

namespace VibeCollection.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {
        private readonly DatabaseHelper _db;

        public UsersController(DatabaseHelper db)
        {
            _db = db;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<User>>> GetUsers()
        {
            var query = "SELECT * FROM users";
            var table = await _db.ExecuteQueryAsync(query);

            var result = new List<User>();
            foreach (DataRow row in table.Rows)
            {
                result.Add(new User
                {
                    Id = Convert.ToInt32(row["id"]),
                    Username = row["username"].ToString()!,
                    Password = row["password"].ToString()!,
                    Role = row["role"].ToString()!,
                    Email = row["email"].ToString()!,
                    CreatedAt = Convert.ToDateTime(row["created_at"])
                });
            }

            return Ok(result);
        }

        [HttpPost]
        public async Task<ActionResult> CreateUser(User user)
        {
            string query = @"INSERT INTO users (username, password, role, email)
                             VALUES (@username, @password, @role, @email)";
            var parameters = new List<MySqlParameter>
            {
                new("@username", user.Username),
                new("@password", user.Password),
                new("@role", user.Role),
                new("@email", user.Email)
            };

            int rows = await _db.ExecuteNonQueryAsync(query, parameters);
            return rows > 0 ? Ok(new { message = "User created" }) : BadRequest("Insert failed");
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult> DeleteUser(int id)
        {
            string query = "DELETE FROM users WHERE id = @id";
            var parameters = new List<MySqlParameter> { new("@id", id) };
            int rows = await _db.ExecuteNonQueryAsync(query, parameters);
            return rows > 0 ? Ok(new { message = "User deleted" }) : NotFound();
        }
    }
}

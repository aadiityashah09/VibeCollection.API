﻿using MySql.Data.MySqlClient;
using System.Data;

namespace VibeCollection.API.Data
{
    public class DatabaseHelper
    {
        private readonly IConfiguration _configuration;
        private readonly string _connectionString;

        public DatabaseHelper(IConfiguration configuration)
        {
            _configuration = configuration;
            _connectionString = _configuration.GetConnectionString("DefaultConnection");
        }

        public async Task<DataTable> ExecuteQueryAsync(string query, List<MySqlParameter>? parameters = null)
        {
            var dataTable = new DataTable();
            using var connection = new MySqlConnection(_connectionString);
            using var command = new MySqlCommand(query, connection);
            if (parameters != null) command.Parameters.AddRange(parameters.ToArray());
            await connection.OpenAsync();
            using var reader = await command.ExecuteReaderAsync();
            dataTable.Load(reader);
            return dataTable;
        }

        public async Task<int> ExecuteNonQueryAsync(string query, List<MySqlParameter>? parameters = null)
        {
            using var connection = new MySqlConnection(_connectionString);
            using var command = new MySqlCommand(query, connection);
            if (parameters != null) command.Parameters.AddRange(parameters.ToArray());
            await connection.OpenAsync();
            return await command.ExecuteNonQueryAsync();
        }
    }
}
